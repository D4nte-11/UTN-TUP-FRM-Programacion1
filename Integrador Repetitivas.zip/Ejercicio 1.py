# Ejercicio 1

opcion = True
while opcion:
    nombre = input("Ingrese su nombre: ").strip()
    nombreEspacios = nombre.replace(" ", "")
    if not nombreEspacios.isalpha():
        print("El nombre ingresado no es válido, por favor ingrese su nombre sin números o símbolos")
        continue

    while True:     
        cantidad = input("Ingrese la cantidad de productos a comprar: ")
        if cantidad.isdigit():
            cantidadInt = int(cantidad)
            if cantidadInt > 0:
                break
            else:
                print("La cantidad debe ser mayor a 0")
        else:
            print("La cantidad indicada no es válida, por favor ingrese un número válido")

    numero = 1
    TotalSinDescuento = 0
    TotalConDescuento = 0

    for i in range(cantidadInt):

        while True:
            producto = input(f"Ingrese el producto {numero}: ").strip()
            productoEspacios = producto.replace(" ", "")

            if not productoEspacios.isalpha():
                print("El producto ingresado no es válido")
            else:
                break

        while True:
            precio = input("Ingrese el precio del producto: ")
            if precio.isdigit():
                precioFloat = float(precio)
                if precioFloat > 0:
                    TotalSinDescuento += precioFloat
                    break
            else:
                print("El precio ingresado no es válido")

        while True:
            descuento = input("El producto tiene descuento? s/n :").lower()
            if descuento in ["s", "n"]:
                if descuento == "s":
                    precioFloat = float(precio)
                    precioDescuento = precioFloat * 0.9
                    TotalConDescuento += precioDescuento
                    break
                elif descuento == "n":
                    TotalConDescuento += precioFloat
                    break
            else:
                print("la opcion elegida no es válida")
        print(f"Producto {numero} - Precio: {precioFloat} Descuento (S/N): {descuento} \n")    
        numero += 1
    Ahorro = TotalSinDescuento - TotalConDescuento
    Promedio = TotalConDescuento / cantidadInt
    print(f" Cliente: {nombre} \n Cantidad de productos: {cantidadInt} \n Total sin descuentos: {TotalSinDescuento:.2f} \n Total con descuentos: {TotalConDescuento:.2f} \n Ahorro: {Ahorro:.2f} \n Promedio por producto: {Promedio:.2f}")
    opcion = False