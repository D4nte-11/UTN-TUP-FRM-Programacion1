#Ejercicio 4

opcion = 0
energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""
intentos = 0
mensaje = 0


while True:
    nombre1 = input("Ingrese su nombre Agente: ").title().strip()
    nombre = nombre1.replace(" ", "")
    print(" ")
    if nombre.isalpha():
        break
    else:
        print("Error: El nombre ingresado no es válido \n")

while True:
    
    if energia > 0 and tiempo > 0 and cerraduras_abiertas < 3:
        
        if alarma and tiempo <= 3 and cerraduras_abiertas < 3:
            print("Bloqueo de sistema. \n DERROTA")

        if mensaje == 0:
            print(f"Bienvenido a La Bóveda Agente {nombre1}, su misión es abrir todas las cerraduras antes de que se acabe el tiempo o la energía \n Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: Desactivada \n Cerraduras abiertas: {cerraduras_abiertas} \n Buena suerte! \n")
            mensaje += 1
        opcion = input("1) Forzar Cerradura \n 2) Hackear panel \n 3) Descansar \n 4) Info \n Seleccione una opción: ")
        print(" ")
        
        if opcion.isdigit():
            opcion = int(opcion)
                
            if opcion >= 1 and opcion <= 4:
                while opcion == 1:
                    if intentos < 2 and energia > 40 and tiempo >= 2:
                        print("Has forzado la cerradura con éxito. \n")
                        intentos += 1
                        energia -= 20
                        tiempo -= 2
                        cerraduras_abiertas += 1
                        if alarma:
                            alarmaTrad = "Activada"
                        else:
                            alarmaTrad = "Desactivada"
                        print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                        break
                    elif energia <= 40 and intentos <= 2 and tiempo >= 2:
                        forzar = input("Tienes Baja energía para forzar la cerradura, porfavor elija un número del 1 al 3: ")
                        print(" ")
                        if forzar.isdigit():
                            forzar = int(forzar)
                            if (forzar == 1 or forzar == 2) and not alarma :
                                print("Has forzado la cerradura con éxito. \n")
                                intentos += 1
                                energia -= 20
                                tiempo -= 2
                                cerraduras_abiertas += 1
                                if alarma:
                                    alarmaTrad = "Activada"
                                else:
                                    alarmaTrad = "Desactivada"
                                print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                                break
                            elif forzar == 3:
                                print("Fallaste al intentar forzar. \n")
                                print("Has activado la alarma! \n")
                                intentos +=1
                                energia -= 20
                                tiempo -= 2
                                alarma = True
                                if alarma == False:
                                    alarmaTrad = "Desactivada"
                                else:
                                    alarmaTrad = "Activada"
                                print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                                break
                            else:
                                print("Error: El número ingresado no es válido. \n")
                        else:
                            print("Error: El número ingresado no es válido. \n")

                    elif intentos == 2 and energia > 40 and tiempo >= 2:
                        print("Intentaste forzar demasiadas veces y trabaste la cerradura, activaste la alarma! \n")
                        intentos += 1
                        energia -= 20
                        tiempo -= 2
                        alarma = True
                        if alarma == False:
                            alarmaTrad = "Desactivada"
                        else:
                            alarmaTrad = "Activada"
                        print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                        break
                    elif intentos >= 3:
                        print("Ya no puedes seguir forzando, cerradura trabada. \n")
                        if alarma:
                            alarmaTrad = "Activada"
                        else:
                            alarmaTrad = "Desactivada"
                        print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                        break
                    elif energia < 20:
                        print("Energía insuficiente para forzar cerradura. \n")
                        if alarma:
                            alarmaTrad = "Activada"
                        else:
                            alarmaTrad = "Desactivada"
                        print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                        break
                    elif tiempo < 2:
                        print("Tiempo insuficiente para forzar cerradura. \n")
                        if alarma:
                            alarmaTrad = "Activada"
                        else:
                            alarmaTrad = "Desactivada"
                        print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                        break
                    elif energia < 20 and tiempo < 2:
                        print("Energía y tiempo insuficientes para forzar cerradura. \n")
                        if alarma:
                            alarmaTrad = "Activada"
                        else:
                            alarmaTrad = "Desactivada"
                        print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                        break
                
                while opcion == 2:
                    intentos = 0
                    if energia >= 10 and tiempo >= 3:
                        energia -= 10
                        tiempo -= 3
                        for i in range(1, 5):
                            progreso = "#" * i + "-" * (4 - i)
                            print(f"Hackeando... [{progreso}]")
                            codigo_parcial += "A"
                        if len(codigo_parcial) < 8:
                            print(f"Error: Hackeo Fallido")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif len(codigo_parcial) >= 8:
                            print("Hackeo exitoso, cerradura desbloqueada. \n")
                            cerraduras_abiertas += 1
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                    else:
                        if energia < 10 and tiempo < 3:
                            print("Energía y tiempo insuficientes para el hackeo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif energia < 10:
                            print("Energía insuficiente para el hackeo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif tiempo < 3:
                            print("Tiempo insuficiente para el hackeo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                
                while opcion == 3:
                    intentos = 0
                    if not alarma:
                        if energia >= 85 and energia != 100:
                            recarga = 100 - energia
                            energia += recarga
                            tiempo -= 1
                            print(f"Recargaste {recarga} de energía, -1 en tiempo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif energia < 85:
                            energia += 15
                            tiempo -= 1
                            print("Recargaste 15 de energía, -1 de tiempo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif energia == 100:
                            print("No puedes descansar, tu energía ya está al máximo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                    else:
                        if energia >= 95 and energia != 100:
                            recarga = 100 - energia
                            energia += recarga
                            tiempo -= 1
                            print(f"Recargaste {recarga} de energía, -1 en tiempo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif energia < 95:
                            energia += 5
                            tiempo -= 1
                            print("Recargaste 5 de energía, -1 de tiempo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                        elif energia == 100:
                            print("No puedes descansar, tu energía ya está al máximo. \n")
                            if alarma:
                                alarmaTrad = "Activada"
                            else:
                                alarmaTrad = "Desactivada"
                            print(f"Estado: \n Energía: {energia} \n Tiempo: {tiempo} \n Alarma: {alarmaTrad} \n Cerraduras abiertas: {cerraduras_abiertas} \n")
                            break
                if opcion == 4:
                    print(" Forzar cerradura: -20 Energía -2 Tiempo \n Hackear: -10 Energía -3 Tiempo. \n")        
            else:
                print("Error: El numero ingresado debe estar entre 1 y 5. \n")
        else:
            print("Error: La opción elegída no es válida. \n")
    
    elif alarma and tiempo <= 3:
        print("Sistema Bloqueado. \n DERROTA (bloqueo) \n")
        break
    elif cerraduras_abiertas == 3:
        print(f"Bóveda abierta, buen trabajo agente {nombre1}. \n VICTORIA")
        break
    elif energia == 0 or tiempo == 0:
        print("Te quedaste sin recursos. \n DERROTA")
        break