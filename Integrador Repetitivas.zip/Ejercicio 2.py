#Ejercicio 2

usuario = "alumno"
contraseña = "python123"
intentos = 0

print("Bienvenido al Campus \n")

for i in range(3):
    user = input("Ingrese el usuario: ")
    password = input("Ingrese la contraseña: ")
    intentos += 1
    if user == usuario and contraseña == password:
        print(f"Intento {i + 1}/3 - Usuario: {user} \n Clave: {password} \n Acceso concedido. \n")
        break
    elif i + 1 == 3:
        print(f"Intento {i + 1}/3 - Usuario: {user} \n Clave: {password} \n Error: Credenciales inválidas")
        print("Cuenta bloqueada")
        intentos += 1
        break
    else:
        print(f"Intento {i + 1}/3 - Usuario: {user} \n Clave: {password} \n Error: Credenciales inválidas")
opcion = 0
while opcion != 4 and intentos <= 3:

    opcion = input("1) Estado de inscrición \n 2) Cambiar clave \n 3) Mensaje motivacional \n 4) Salir \n Ingrese una opción:")
    print(" ")
    if opcion.isdigit():
        opcion = int(opcion)

        if opcion <= 4 and opcion > 0:
            if opcion == 1:
                print("Inscripto \n")

            elif opcion == 2:
                while True:    
                    contraseñaAnterior = input("Ingrese su contraseña anterior o presione 9 para salir: ")
                    if contraseñaAnterior == "9":
                        break
                    elif contraseñaAnterior == contraseña:
                        nuevaClave = input("Ingrese su nueva contraseña: ")
                        confirmarClave = input("Repita la contraseña: ")
                        
                        if nuevaClave == confirmarClave:
                            if len(nuevaClave) < 6:
                                print("Error: mínimo 6 caracteres.")
                            else:
                                contraseña = confirmarClave
                                print("Contraseña cambiada con éxito. \n")
                                break
                        elif nuevaClave != confirmarClave:
                            print("Error: las contraseñas ingresadas no coinciden.")
                    else:
                        print("Error: La contraseña no es correcta")
            elif opcion == 3:
                print("Estudiar no es solo aprobar materias, es construir la versión de vos que todavía no existe. Cada día que seguís, aunque cueste, ya te está acercando a ella \n")
        else:
            print(f"Opción: {opcion}")
            print("Error: opción fuera de rango.")

    else:
        print(f"Opción: {opcion}")
        print("Error: ingrese un número válido")