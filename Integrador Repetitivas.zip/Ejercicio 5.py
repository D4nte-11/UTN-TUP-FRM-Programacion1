#Ejercicio 5

opcion = 0
vidaG = 100
vidaE = 100
pociones = 3
dañoBG = 15
dañoBE = 12
turnoG = True
mensaje = 0

print("--- BIENVENIDO A LA ARENA ---")
while True:
    if vidaE <= 0 or vidaG <= 0:
        break
    gladiador = input("Introduzca el nombre del gladiador: ").strip().title()
    gladiador1 = gladiador.replace(" ", "")
    if gladiador1.isalpha():
        print(f"Nombre del gladiador {gladiador}")
        print("--- INICIO DE COMBATE ---")
        for i in range(1):
            print(f"{gladiador} (HP: {vidaG}) vs Enemigo (HP: {vidaE} | Pociones {pociones})")
            while True: 
                opcion = input("Elija una acción: \n 1) Ataque Pesado \n 2) Ráfaga Veloz \n 3) Curar \n Opción: ")
                print(" ")
                if opcion.isdigit():
                    opcion = int(opcion)
                    if opcion >= 1 and opcion <= 3:
                        while opcion == 1:
                            if vidaE <= 20 and vidaE > 0 and vidaG > 0:
                                dañoBGC = dañoBG * 1.5
                                print(f"Golpe crítico \n >>Atacaste al enemigo por {dañoBGC} puntos de daño.")
                                vidaE -= dañoBGC
                                turnoG = False
                                break
                            elif vidaE > 20 and vidaE > 0 and vidaG > 0:
                                print(f"Buen Golpe! \n >>Atacaste al enemigo por {dañoBG} puntos de daño.")
                                vidaE = vidaE - dañoBG
                                turnoG = False
                                break

                        if opcion == 2:
                            for i in range(3):
                                print(" >Golpe conectado por 5 de daño")
                                vidaE -= 5
                            turnoG = False

                        if opcion == 3:
                            if pociones > 0:
                                vidaG += 30
                                pociones -= 1
                                print("\n >>Restauraste 30 de vida.")
                                turnoG = False
                            else:
                                print("\nNo te quedan pociones! \n")
                                turnoG = False

                        if  not turnoG and vidaE > 0:
                            print(f"\n >>El enemigo te atacó por {dañoBE} puntos de daño.")     
                            vidaG -= dañoBE
                            turnoG = True
                            if vidaE > 0 and vidaG > 0:
                                print(f"\n {gladiador} (HP: {vidaG}) vs Enemigo (HP: {vidaE}) | Pociones {pociones} \n")
                    else:
                        print("Error: La opción elegida tiene que estar entre 1 y 3")       
                        
                else:
                    print("Error: La opción es incorrecta. \n")
                    
                if vidaG > 0 and vidaE <= 0:
                    print(f"\n Victoria! {gladiador} ha ganado la batalla.")
                    break
                elif vidaG <= 0 and vidaE > 0:
                    print("\n DERROTA. Has caído en combate. \n") 
                    break
    else:
        print("Error: Solo se permiten letras")