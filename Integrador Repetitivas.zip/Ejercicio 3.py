#Ejercicio 3

opcion = 0
Lunes = 0
Martes = 0

Lunes1 = ""
Lunes2 = ""
Lunes3 = ""
Lunes4 = ""
Martes1 = ""
Martes2 = ""
Martes3 = ""

while True:
    operador = input("Ingrese su nombre: ")
    operadorEsp = operador.replace(" ", "")

    if not operador.isalpha():
        print("Error: Solo se admiten letras \n")

    else:
        break
    
while opcion != 5:
    opcion = input("1) Reservar turno \n 2) Cancelar turno \n 3) Ver agenda \n 4) Ver Resumen General \n 5) Cerrar sistema \n Elija un opción: ")
    print("")

    if opcion.isdigit():
        opcion = int(opcion)
        
        if opcion > 0 and opcion <= 5:
            while opcion == 1:
                reserva = input("Presione 1 para reservar el Lunes, presione 2 Para reservar el Martes: ")
                print("")

                if reserva.isdigit():
                    reserva = int(reserva)

                    if reserva == 1:
                        print("Turno reservado para el Lunes \n")

                    elif reserva == 2:
                        print("Turno reservado para el Martes \n")

                    else:
                        print("Error: la opcion seleccionada es incorrecta \n")
                        continue


                    while True:
                        nombre = input("Ingrese el nombre del paciente: ").title().strip()
                        print("")
                        nombre = nombre.replace(" ", "")

                        if nombre.isalpha():

                            if reserva == 1:

                                if Lunes1 == nombre or Lunes2 == nombre or Lunes3 == nombre or Lunes4 == nombre:
                                    print("Error: Este paciente ya tiene turno este día \n")
                                    break

                                else:
                                    if Lunes == 0:
                                        Lunes1 = nombre
                                    elif Lunes == 1:
                                        Lunes2 = nombre
                                    elif Lunes == 2:
                                        Lunes3 = nombre
                                    elif Lunes == 3:
                                        Lunes4 = nombre
                                    else:
                                        print("No hay más turnos para el lunes \n")
                                        break
                                    
                                    Lunes += 1
                                    opcion = 0
                                    break

                            elif reserva == 2:
                                if Martes1 == nombre or Martes2 == nombre or Martes3 == nombre:
                                    print("Error: Este paciente ya tiene turno este día \n")
                                    break

                                else:
                                    if Martes == 0:
                                        Martes1 = nombre
                                    elif Martes == 1:
                                        Martes2 = nombre
                                    elif Martes == 2:
                                        Martes3 = nombre
                                    elif Martes == 3:
                                        Martes4 = nombre
                                    else:
                                        print("No hay más turnos para el Martes \n")
                                        break

                                    Martes += 1
                                    opcion = 0
                                    break
                        else:
                            print("Error: El nombre ingresado no es válido.")                 
                else:
                    print("Error: La opcion ingresada es incorrecta \n")
            while opcion == 2:
                cancelar = input("Marque 1 para cancelar un turno el Lunes, 2 para cancelar turno el Martes: ")
                print("")
                if cancelar.isdigit():
                    cancelar = int(cancelar)
                    if cancelar == 1:
                        nombreCancel = input("Ingrese el nombre del paciente: ").title().strip()
                        nombreCancel = nombreCancel.replace(" ", "")
                        if Lunes1 == nombreCancel:
                            Lunes1 = ""
                            print("Turno eliminado.  \n")
                        elif Lunes2 == nombreCancel:
                            Lunes2 = ""
                            print("Turno eliminado.  \n")
                        elif Lunes3 == nombreCancel:
                            Lunes3 = ""
                            print("Turno eliminado.  \n")
                        elif Lunes4 == nombreCancel:
                            Lunes4 = ""
                            print("Turno eliminado.  \n")
                        else:
                            print("Error: El nombre ingresado no tiene reserva para el Lunes. \n")
                            break
                        if Lunes > 0:
                            Lunes -= 1
                        break

                    if cancelar == 2:
                        nombreCancel = input("Ingrese el nombre del paciente: ").title().strip()
                        nombreCancel = nombreCancel.replace(" ", "")
                        print("")
                        if Martes1 == nombreCancel:
                            Martes1 = ""
                            print("Turno eliminado.  \n")
                        elif Martes2 == nombreCancel:
                            Martes2 = ""
                            print("Turno eliminado.  \n")
                        elif Martes3 == nombreCancel:
                            Martes3 = ""
                            print("Turno eliminado.  \n")
                        else:
                            print("Error: El nombre ingresado no tiene reserva para el Martes. \n")
                            break
                        if Martes > 0:
                            Martes -= 1
                        break
                else:
                    print("Error: La opcion elegida no es válida. \n")
            
            while opcion == 3:
                dia = input("Ingrese 1 si desea ver los turnos del Lunes, 2 si desea ver los turnos del martes: ")
                print("")
                if dia.isdigit():
                    dia = int(dia)
                    if dia == 1:
                        if Lunes1 != "":
                            print(f"Turno 1 Lunes: {Lunes1} ")
                        else: print("Turno 1 Lunes: Libre")
                        if Lunes2 != "":
                            print(f"Turno 2 Lunes: {Lunes2} ")
                        else: print("Turno 2 Lunes: Libre")
                        if Lunes3 != "":
                            print(f"Turno 3 Lunes: {Lunes3} ")
                        else: print("Turno 3 Lunes: Libre")

                        if Lunes4 != "":
                            print(f"Turno 4 Lunes: {Lunes4} ")
                        else: print("Turno 4 Lunes: Libre \n")

                    elif dia == 2:
                        if Martes1 != "":
                            print(f"Turno 1 Martes: {Martes1} ")
                        else: print("Turno 1 Martes: Libre")

                        if Martes2 != "":
                            print(f"Turno 2 Martes: {Martes2} ")
                        else: print("Turno 2 Martes: Libre")

                        if Martes3 != "":
                            print(f"Turno 3 Martes: {Martes3} ")
                        else: print("Turno 3 Martes: Libre \n")

                    else:
                        print("Error: el número ingresado no es válido. \n")
                    
                    break
            
            while opcion == 4:
                
                if Lunes1 != "":
                    print(f"Turno 1 Lunes: {Lunes1} ")
                else: print("Turno 1 Lunes: Libre")
                if Lunes2 != "":
                    print(f"Turno 2 Lunes: {Lunes2} ")
                else: print("Turno 2 Lunes: Libre")
                if Lunes3 != "":
                    print(f"Turno 3 Lunes: {Lunes3} ")
                else: print("Turno 3 Lunes: Libre")

                if Lunes4 != "":
                    print(f"Turno 4 Lunes: {Lunes4} ")
                else: print("Turno 4 Lunes: Libre \n")

                if Martes1 != "":
                    print(f"Turno 1 Martes: {Martes1} ")
                else: print("Turno 1 Martes: Libre")

                if Martes2 != "":
                    print(f"Turno 2 Martes: {Martes2} ")
                else: print("Turno 2 Martes: Libre")

                if Martes3 != "":
                    print(f"Turno 3 Martes: {Martes3} ")
                else: print("Turno 3 Martes: Libre \n")

                if Lunes > Martes:
                    print(f"El Lunes tiene más turnos ocupados con {Lunes} turnos. \n")
                elif Martes > Lunes:
                    print(f"El Martes tiene más turnos ocupados con {Martes} turnos. \n")
                elif Lunes == Martes:
                    Lurtes = Lunes + Martes
                    if Lurtes > 0:
                        print(f"Ambos días tienen la misma cantidad de turnos ocupados, con {Lunes} turnos \n")
                    elif Lurtes == 0:
                        print("Todos los turnos están disponibles. \n")
                    else:
                        print("Error desconocido")                
                break
        else:
            print("Error: La opción debe estar entre 1 y 5. \n")
    else:
        print("Error: La opción seleccionada es incorrecta. \n")